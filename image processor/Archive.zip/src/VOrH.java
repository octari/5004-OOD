/**
 * This enum represents the rainbow stripes should be vertical or horizontal.
 * There are only 2 options.
 */
public enum VOrH {
  vertical, horizontal
}
