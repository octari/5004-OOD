import java.io.IOException;

/**
 * The interface represents a controller of the image processing program. It contains only one
 * public method to the do operations using model according to the user's input.
 */
public interface IController {
  /**
   * Do corresponding operation according to the user's input.
   *
   * @throws IOException when it fails to read or write a file.
   */
  void executeCommands() throws IOException;

  ImageReader load(String load) throws IOException;

  void operate(String[] operation, ImageReader origin);

  void save(ImageReader processed, String save) throws IOException;

  ImageReader generate(String path, String[] generation)throws IOException;
}
