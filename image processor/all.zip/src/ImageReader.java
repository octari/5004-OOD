import java.io.IOException;

/**
 * This class represent an image by the 3D array, height and width.
 * It can be construct by an image file directly or by a 3D array, height and width.
 */
public class ImageReader {
  private int [][][] array;
  private int height;
  private int width;

  public ImageReader(String file) throws IOException {
    array = ImageUtil.readImage(file);
    height = ImageUtil.getHeight(file);
    width = ImageUtil.getWidth(file);
  }
  public ImageReader(int[][][]array, int width, int height){
    this.array = array;
    this.height =height;
    this.width = width;
  }

  public int getHeight() {
    return height;
  }

  public int[][][] getArray() {
    return array;
  }

  public int getWidth() {
    return width;
  }

  public void setArray(int[][][] array) {
    this.array = array;
  }
}
