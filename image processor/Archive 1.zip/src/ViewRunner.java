import java.io.IOException;

import javax.swing.*;

  public class ViewRunner {

    public static void main(String[] args) {
      try {
        // Set cross-platform Java L&F (also called "Metal")
        UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());

        //UIManager.setLookAndFeel( UIManager.getSystemLookAndFeelClassName());

        //   UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
        //    UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
        //    for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
        //    {
        //       if ("Nimbus".equals(info.getName())) {
        //          UIManager.setLookAndFeel(info.getClassName());
        //         break;
        //    }
        // }
      } catch (UnsupportedLookAndFeelException e) {
        // handle exception
      } catch (ClassNotFoundException e) {
        // handle exception
      } catch (InstantiationException e) {
        // handle exception
      } catch (IllegalAccessException e) {
        // handle exception
      } catch (Exception e) {
      }

     View.setDefaultLookAndFeelDecorated(false);
      View frame = new View();

      frame.setResizable(false);

      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setVisible(true);
      NewController c = new NewController(new ImageImpl(), frame);



      //c.setView();

    }

  }

