import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;
public class Menu extends JFrame {

  private JMenuBar jmb;
  private JMenu file, process, run, edit;
  private JMenu subNew ;
  private JMenuItem checker, command,rainbow, flag,blur, sharpen, greyscale, sepia, dither, mosaic;
  private JMenuItem subLoad, subSave,undo,redo;
//  public static void main(String[] args) {
//    Swing_JMenu a = new Swing_JMenu();
//
//  }

  public Menu() {

    jmb = new JMenuBar();
    //jmb.setPreferredSize(new Dimension(240, 0));
    file = new JMenu("File");
    //file.setPreferredSize(new Dimension(80, 0));
    process = new JMenu("Process");
   // process.setPreferredSize(new Dimension(80, 0));
    run = new JMenu("Run");

    edit = new JMenu("Edit");
    //run.setPreferredSize(new Dimension(80, 0));
    //command.setPreferredSize(new Dimension(10, 0));


    subNew = new JMenu("New");
    subLoad = new JMenuItem("Load...");
    subSave = new JMenuItem("Save");

    checker = new JMenuItem("Checkerboard");
    rainbow = new JMenuItem("Rainbow");
    flag = new JMenuItem("Flag");

    command = new JMenuItem("Execute Input");

    blur = new JMenuItem("Blur");
    sharpen = new JMenuItem("Sharpen");
    greyscale = new JMenuItem("Greyscale");
    sepia = new JMenuItem("Sepia tone");
    dither = new JMenuItem("Dither");
    mosaic = new JMenuItem("Mosaic");

    undo = new JMenuItem("Undo");
    redo = new JMenuItem("Redo");



    edit.add(undo);
    edit.add(redo);

    subNew.add(checker);
    subNew.add(rainbow);
    subNew.add(flag);

    file.add(subNew);
    file.add(subLoad);
    file.add(subSave);

    process.add(blur);
    process.add(sharpen);
    process.add(greyscale);
    process.add(sepia);
    process.add(dither);
    process.add(mosaic);
    run.add(command);

    jmb.add(file);
    jmb.add(edit);
    jmb.add(process);
    jmb.add(run);

    subLoad.setActionCommand("Open file");
    checker.setActionCommand("generate checker");
    mosaic.setActionCommand("mosaic");
    flag.setActionCommand("generate flag");
    rainbow.setActionCommand("generate rainbow");
    subSave.setActionCommand("Save file");
    blur.setActionCommand("blur");
    sharpen.setActionCommand("sharpen");
    greyscale.setActionCommand("greyscale");
    sepia.setActionCommand("sepia");
    dither.setActionCommand("dither");
    undo.setActionCommand("undo");
    redo.setActionCommand("redo");

  }

  public JMenuBar getJmb(){
    return jmb;
  }

  public void setListeners(ActionListener frame){
    subLoad.addActionListener(frame);
    checker.addActionListener(frame);
    mosaic.addActionListener(frame);
    flag.addActionListener(frame);
    rainbow.addActionListener(frame);
    subSave.addActionListener(frame);
    blur.addActionListener( frame);
    sharpen.addActionListener(frame);
    greyscale.addActionListener( frame);
    sepia.addActionListener(frame);
    dither.addActionListener(frame);
    undo.addActionListener(frame);
    redo.addActionListener(frame);

  }


}
