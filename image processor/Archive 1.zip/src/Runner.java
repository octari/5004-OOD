
import java.io.FileNotFoundException;

/**
 * This class represents a program runner. It has a one main method.
 */
public class  Runner {
  /**
   * The main method to run the program.
   * @param args the input txt file
   * @throws FileNotFoundException when it fails find the input txt file.
   */
  public static void main(String[] args) throws FileNotFoundException {

    new Controller(new ImageImpl(), args[0]).executeCommands();
  }
}
