

import java.awt.*;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.Stack;

import javax.swing.*;

public class NewController implements ActionListener {
  private ImageImpl model;
  private View view;
  private Stack<java.awt.Image> undoStack;
  private Stack<java.awt.Image> redoStack;


  public NewController(ImageImpl image, View view) {
    model = image;
    this.view = view;
    view.setListeners(this);
    undoStack = new Stack<>();
    redoStack = new Stack<>();


  }

  private BufferedImage toBufferedImage(java.awt.Image image) {
    BufferedImage bImage = new BufferedImage(image.getWidth(null), image
            .getHeight(null), BufferedImage.TYPE_INT_ARGB);

    Graphics g = bImage.createGraphics();

    g.drawImage(image, 0, 0, null);
    g.dispose();

    return bImage;
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    switch (e.getActionCommand()) {
      case "Open file":
        String loadPath = view.choosePath();
        view.display(new ImageIcon(loadPath).getImage());
        //undoStack.clear();
        undoStack.push(new ImageIcon(loadPath).getImage());
        redoStack.clear();
        break;
      case "Save file":
        String path = view.savePath();
        BufferedImage curr = toBufferedImage(view.getDisplay());
        try {
          ImageUtil.writeImage(ImageUtil.readBufferedImage(curr), curr.getWidth(), curr.getHeight(), path);
        } catch (IOException e1) {
          e1.printStackTrace();
        }
        break;

      case "generate checker":
        String input = view.setSingleInput("checker size");
        if (input!= null) {
          int checkerSize = Integer.parseInt(input);
          int[][][] checker = model.generateChecker(checkerSize);
          helpDisplayProcess(checker);
          //controlStack();
        }
        break;

      case "generate flag":

        ArrayList<String> flagArguments = view.setFlag();
        if (flagArguments != null) {
          int[][][] flag = model.generateFlags(Integer.parseInt(flagArguments.get(1)),
                  flagArguments.get(0));
          helpDisplayProcess(flag);
        }
        break;

      case "generate rainbow":
        ArrayList<String> rainbowArguments = view.setRainbow();
        if (rainbowArguments != null) {
          int[][][] rainbow = null;
          if (rainbowArguments.get(2).equals("vertical")) {
            rainbow = model.generateRainbow(Integer.parseInt(rainbowArguments.get(0)),
                    Integer.parseInt(rainbowArguments.get(1)), VOrH.vertical);
          } else if (rainbowArguments.get(2).equals("horizontal")) {
            rainbow = model.generateRainbow(Integer.parseInt(rainbowArguments.get(0)),
                    Integer.parseInt(rainbowArguments.get(1)), VOrH.horizontal);
          }
          helpDisplayProcess(rainbow);
        }

        break;

      case "mosaic":
        String inputM = view.setSingleInput("mosaic seed");
        if(inputM != null) {
          int seed = Integer.parseInt(inputM);
          BufferedImage toMosaic = toBufferedImage(view.getDisplay());
          int[][][] mosaic = model.mosaicingImage(ImageUtil.readBufferedImage(toMosaic),
                  toMosaic.getHeight(), toMosaic.getWidth(), seed);
          helpDisplayProcess(mosaic);
        }
        break;
      case "blur":
        BufferedImage toBlur = toBufferedImage(view.getDisplay());
        int[][][] blur = model.blurImage(ImageUtil.readBufferedImage(toBlur),
                toBlur.getHeight(), toBlur.getWidth());
        helpDisplayProcess(blur);

        break;
      case "sharpen":
        BufferedImage toSharpen = toBufferedImage(view.getDisplay());
        int[][][] sharpen = model.sharpenImage(ImageUtil.readBufferedImage(toSharpen),
                toSharpen.getHeight(), toSharpen.getWidth());
        helpDisplayProcess(sharpen);
        break;

      case "greyscale":
        BufferedImage toGrey = toBufferedImage(view.getDisplay());
        int[][][] greyscale = model.greyscaleImage(ImageUtil.readBufferedImage(toGrey),
                toGrey.getHeight(), toGrey.getWidth());
        helpDisplayProcess(greyscale);
        break;

      case "sepia":
        BufferedImage toSepia = toBufferedImage(view.getDisplay());
        int[][][] sepia = model.sepiaToneImage(ImageUtil.readBufferedImage(toSepia),
                toSepia.getHeight(), toSepia.getWidth());
        helpDisplayProcess(sepia);
        break;

      case "dither":
        BufferedImage toDither = toBufferedImage(view.getDisplay());
        int[][][] dither = model.ditheringImage(ImageUtil.readBufferedImage(toDither),
                toDither.getHeight(), toDither.getWidth());
        helpDisplayProcess(dither);
        break;

      case "undo":
        try {
          Image toStore = undoStack.pop();
          Image toShow = undoStack.peek();
          view.display(toShow);
          redoStack.push(toStore);
        }
        catch (EmptyStackException noUndo){
          view.cantDo("undo");
        }
        break;

      case "redo":
        try {
         // redoStack.pop();
          Image toShow = redoStack.pop();
          view.display(toShow);
          undoStack.push(toShow);
        }
        catch (EmptyStackException noRedo){
          view.cantDo("redo");
        }
        break;

      default:
        break;

    }
  }

  private void helpDisplayProcess(int[][][] display) {
    Image toDisplay = ImageUtil.convertToImage(display, display[0].length, display.length);
    view.display(toDisplay);
    undoStack.push(toDisplay);
    redoStack.clear();
  }
}
