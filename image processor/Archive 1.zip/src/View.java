import java.awt.*;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;


import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

public class View extends JFrame {
  private Menu jmb;
  private JPanel output;
  private JPanel contentPane;
  private JTextArea commands;
  private JLabel imageLabel;
  //<<<<<<< HEAD
//  private JScrollPane scrollPane;
//  private String image; // the filename of the image to be displayed
//  //=======
//  // private String image;// the filename of the image to be displayed
//  private int[][][] currentPixel;
//  private BufferedImage newImage;
//  private int w;
//  private int h;
//  private LinkedList<int[][][]> imageStack = new LinkedList<int[][][]>();
//  private LinkedList<int[][][]> tempImageStack = new LinkedList<int[][][]>();

//>>>>>>> 0dacf5059d98dc07a7791c2ab1a7269171c5f1ed

  private ImageIcon display;
//  private String savePath;
//  private String loadPath;
//
//
//  private ArrayList<String> arguments;// to hold all the arguments required by controller from user

  public View() {

    super();
//    savePath = null;
//    loadPath = null;
//    arguments = new ArrayList<>();
    display = new ImageIcon();
    setTitle("Image Tool");
    setSize(600, 600);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    jmb = new Menu();
    //this.setJMenuBar(jmb.getJmb());
    //this.getContentPane().add(jmb.getJmb(), BorderLayout.PAGE_START);


    contentPane = new JPanel(new BorderLayout());
    contentPane.setOpaque(true);

    //Create a scrolled text area.
    output = new JPanel();
    imageLabel = new JLabel();
    JScrollPane scrollPane = new JScrollPane(imageLabel);
    //TODO place holder to show the example
    //TODO change the image to display
    imageLabel.setIcon(display);
//imageLabel.setIcon(new ImageIcon("candy.png"));
    //ImageIcon i = new ImageIcon(ImageUtil.convertImage([][][], w, h));

    scrollPane.setPreferredSize(new Dimension(600, 600));
    output.add(scrollPane);
    output.setBorder(BorderFactory.createTitledBorder("Image Display"));
    // output.setLayout(new GridLayout(1, 0, 10, 10));
    output.setMaximumSize(null);
    //output.setAutoscrolls(true);
    //Add the text area to the content pane.
    contentPane.add(output, BorderLayout.CENTER);

    commands = new JTextArea(10, 20);
    JScrollPane scrollText = new JScrollPane(commands);
    scrollText.setBorder(BorderFactory.createTitledBorder("Batch Script"));
    contentPane.add(scrollText, BorderLayout.SOUTH);


//    JPanel dialogBoxesPanel = new JPanel();
//    dialogBoxesPanel.setBorder(BorderFactory.createTitledBorder("Dialog boxes"));
//    dialogBoxesPanel.setLayout(new BoxLayout(dialogBoxesPanel, BoxLayout.PAGE_AXIS));
//   contentPane.add(dialogBoxesPanel);
   // jmb.setListeners(this);
    setContentPane(contentPane);
    setJMenuBar(jmb.getJmb());
//
//   // show an image with a scrollbar
//    JPanel imagePanel = new JPanel();
//    //a border around the panel with a caption

//
//
//
//    String images = "manhattan.png";
//    JLabel imageLabel = new JLabel();
//    //JScrollPane imageScrollPane = new JScrollPane();
//
////    for (int i = 0; i < imageLabel.length; i++) {
//      //imageLabel[i] = new JLabel();
//      JScrollPane imageScrollPane = new JScrollPane(imageLabel);
//
//      imageLabel.setIcon(new ImageIcon(images));
//      imageScrollPane.setPreferredSize(new Dimension(400, 400));
//      imagePanel.add(imageScrollPane);
//      //getContentPane().add(imagePanel,BorderLayout.CENTER);
//      this.setContentPane(imagePanel);
//      this.setJMenuBar(jmb.getJmb());
    //getContentPane().add(jmb.getJmb(), BorderLayout.PAGE_START);

    this.pack();


    //text area with a scrollbar
//    JTextArea sTextArea = new JTextArea(1, 1);
//    JScrollPane scrollPane = new JScrollPane(sTextArea);
//    sTextArea.setLineWrap(true);
//    scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
//    scrollPane.setBorder(BorderFactory.createTitledBorder("Scrollable text area"));
//    mainPanel.add(scrollPane);
  }


  //@Override
  //After execution, clear the argument.
//  public void actionPerformed(ActionEvent e) {
//    int[][][] result;
//
//    switch (e.getActionCommand()) {
//<<<<<<<HEAD
//      case "Open file": {
//        final JFileChooser fchooser = new JFileChooser(".");
//        FileNameExtensionFilter filter = new FileNameExtensionFilter(
//                "JPG & PNG Images", "jpg", "png");
//        fchooser.setFileFilter(filter);
//        int retvalue = fchooser.showOpenDialog(View.this);
//        if (retvalue == JFileChooser.APPROVE_OPTION) {
//
//          File f = fchooser.getSelectedFile();
//          loadPath = f.getAbsolutePath();
////          image = f.getAbsolutePath();
////          imageLabel.setIcon(new ImageIcon(image));
////          imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
//          //fileOpenDisplay.setText(f.getAbsolutePath());
//        }
//      }
      // break;
//      case "Save file": {
//        final JFileChooser fchooser = new JFileChooser(".");
//        int retvalue = fchooser.showSaveDialog(View.this);
//        if (retvalue == JFileChooser.APPROVE_OPTION) {
//          File f = fchooser.getSelectedFile();
//          savePath = f.getAbsolutePath();
//          System.out.println(f.getAbsolutePath());
//          //fileSaveDisplay.setText(f.getAbsolutePath());
//        }
//      }
//      break;


//      case "generate checker":
//        CustomDialog sizeSelector = new CustomDialog( "Checkerboard size",
//                this, this);
//        sizeSelector.setVisible(true);
//        System.out.println(arguments);
//        //String s = sizeSelector.getValidatedText();
//        //sizeSelector.setLocationRelativeTo(this.imageLabel);
//
//       // getNumberArgument(sizeSelector.getValidatedText());
//        break;
//      case "generate flag":
//        FlagDialog flagSelector = new FlagDialog(this);
//        flagSelector.setVisible(true);
//        //System.out.println(arguments);
//        break;

//      case "generate rainbow":
//        RainbowDialog rainbowSelector = new RainbowDialog(this, this);
//        rainbowSelector.setVisible(true);
//        System.out.println(arguments);
//        break;
//=======
//      case "Open file":
//        final JFileChooser fchooser = new JFileChooser(".");
//        FileNameExtensionFilter filter = new FileNameExtensionFilter(
//                "JPG & PNG Images", "jpg", "png");
//        fchooser.setFileFilter(filter);
//        int retvalue = fchooser.showOpenDialog(View.this);
//        if (retvalue == JFileChooser.APPROVE_OPTION) {
//          File f = fchooser.getSelectedFile();
//          image = f.getAbsolutePath();
//          try {
//            ImageReader a = new ImageReader(image);
//            w = a.getWidth();
//            h = a.getHeight();
//            currentPixel = a.getArray();
//            newImage = ImageUtil.convertImage(currentPixel,w,h);
//            imageStack.clear();
//            tempImageStack.clear();
//            imageStack.addLast(currentPixel);
//            imageLabel.setIcon(new ImageIcon(newImage));
//            imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
//          } catch (IOException e1) {
//            e1.printStackTrace();
//          }
//          //fileOpenDisplay.setText(f.getAbsolutePath());
//        }
//      break;
//
//      case "Save file": {
//        final JFileChooser dchooser = new JFileChooser(".");
//        retvalue = dchooser.showSaveDialog(View.this);
//        if (retvalue == JFileChooser.APPROVE_OPTION) {
//          File d = dchooser.getSelectedFile();
//          image = d.getAbsolutePath();
//          try {
//            ImageUtil.writeImage(currentPixel,w,h,image);
//          } catch (IOException e1) {
//            e1.printStackTrace();
//          }
//
//        }
//      }
//      break;
//
//      case "generate checker":
////        String s = (String)JOptionPane.showInputDialog(this,
////                "Enter an size as integer:", "Generate a checkerboard",
////                JOptionPane.PLAIN_MESSAGE,null, null, "0");
//        CustomDialog sizeSelector = new CustomDialog( "Checkerboard size",
//                this, this);
//        sizeSelector.setVisible(true);
//        System.out.println(arguments);
//        int size = Integer.parseInt(arguments.get(0));
//        result = new ImageImpl().generateChecker(size);
//        h = result.length;
//        w= result[0].length;
//        imageStack.addLast(result);
//        currentPixel = result;
//        showImage(result);
//        tempImageStack.clear();
//        clearArgument();
//
//        //String s = sizeSelector.getValidatedText();
//        //sizeSelector.setLocationRelativeTo(this.imageLabel);
//
//       // getNumberArgument(sizeSelector.getValidatedText());
//        break;
//
//      case "generate flag":
//        FlagDialog flagSelector = new FlagDialog(this, this);
//        flagSelector.setVisible(true);
//        System.out.println(arguments);
//        int ratio = Integer.parseInt(arguments.get(1));
//        String country = arguments.get(0);
//        result = new ImageImpl().generateFlags(ratio,country);
//        h = result.length;
//        w= result[0].length;
//        imageStack.addLast(result);
//        currentPixel = result;
//        showImage(result);
//        tempImageStack.clear();
//        clearArgument();
//        break;
//
//      case "generate rainbow":
//        RainbowDialog rainbowSelector = new RainbowDialog(this, this);
//        rainbowSelector.setVisible(true);
//        System.out.println(arguments);
//        h = Integer.parseInt(arguments.get(0));
//        w = Integer.parseInt(arguments.get(1));
//        VOrH vOrH = VOrH.valueOf(arguments.get(2));
//        result = new ImageImpl().generateRainbow(h,w,vOrH);
//        imageStack.addLast(result);
//        currentPixel = result;
//        showImage(result);
//        tempImageStack.clear();
//        clearArgument();
//        break;
//
//>>>>>>> 0dacf5059d98dc07a7791c2ab1a7269171c5f1ed
//      case "mosaic":
//        CustomDialog seedSelector = new CustomDialog( "Seed number",
//                this);
//        seedSelector.setVisible(true);
//        result = new ImageProcessor(currentPixel,h,w).mosaicing(Integer.parseInt(arguments.get(0)));
//        imageStack.addLast(result);
//        currentPixel = result;
//        showImage(result);
//        tempImageStack.clear();
//        clearArgument();
//        break;
//
//      case "blur":
//        result = new ImageProcessor(currentPixel,h,w).blur();
//        imageStack.addLast(result);
//        currentPixel = result;
//        showImage(result);
//        tempImageStack.clear();
//        break;
//
//      case "sharpen":
//        result = new ImageProcessor(currentPixel,h,w).sharpening();
//        imageStack.addLast(result);
//        currentPixel = result;
//        showImage(result);
//        tempImageStack.clear();
//        break;
//
//      case "greyscale":
//        result = new ImageProcessor(currentPixel,h,w).greyScale();
//        imageStack.addLast(result);
//        currentPixel = result;
//        showImage(result);
//        tempImageStack.clear();
//
//        break;
//
//      case "sepia":
//        result = new ImageProcessor(currentPixel,h,w).sepiaTone();
//        imageStack.addLast(result);
//        currentPixel = result;
//        showImage(result);
//        tempImageStack.clear();
//        break;
//
//      case "dither":
//        result = new ImageProcessor(currentPixel,h,w).dithering();
//        imageStack.addLast(result);
//        currentPixel = result;
//        showImage(result);
//        tempImageStack.clear();
//        break;
//
//      case "undo":
//        if (imageStack.size() <= 1) {
//          JOptionPane.showMessageDialog(null, "Has no more undo history operation.",
//                  "notification", JOptionPane.INFORMATION_MESSAGE);
//        } else {
//          tempImageStack.addLast(imageStack.removeLast());
//          currentPixel = imageStack.getLast();
//          showImage(currentPixel);
//        }
//        break;
//
//      case "redo":
//        if (tempImageStack.size() < 1) {
//          JOptionPane.showMessageDialog(null, "Has no more redo history operation.",
//                  "notification", JOptionPane.INFORMATION_MESSAGE);
//        } else {
//          currentPixel = tempImageStack.removeLast();
//          imageStack.addLast(currentPixel);
//          showImage(currentPixel);
//        }
//    }
//
//
//  }
//
//
//
//  public void getArguments(String n) {
//    arguments.add(n);
////    ImageIcon test = new ImageIcon();
////    Image i = ImageUtil.convertImage()
////    test.setImage(i);
//  }
//
//  public void clearArgument(){
//    arguments.clear();
//  }
//
//<<<<<<< HEAD


  public void display(java.awt.Image image) {
    //JScrollPane scrollPane = new JScrollPane(imageLabel);
    display.setImage(image);
    imageLabel.setIcon(new ImageIcon(display.getImage()));
    imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
    imageLabel.revalidate();


  }

  public String choosePath() {
    final JFileChooser fchooser = new JFileChooser(".");
    FileNameExtensionFilter filter = new FileNameExtensionFilter(
            "JPG & PNG Images", "jpg", "png");
    fchooser.setFileFilter(filter);
    // this.add(fchooser);
    // fchooser.setVisible(true);
    int retvalue = fchooser.showOpenDialog(View.this);
    if (retvalue == JFileChooser.APPROVE_OPTION) {

      File f = fchooser.getSelectedFile();
      return f.getAbsolutePath();
    }
    return null;
  }

  public String savePath() {
    final JFileChooser fchooser = new JFileChooser(".");
    int retvalue = fchooser.showSaveDialog(View.this);
    if (retvalue == JFileChooser.APPROVE_OPTION) {
      File f = fchooser.getSelectedFile();
      //savePath = f.getAbsolutePath();
      return f.getAbsolutePath();
      //fileSaveDisplay.setText(f.getAbsolutePath());
    }
    return null;
  }

  public void setListeners(ActionListener clicked) {
    jmb.setListeners(clicked);
  }

  public java.awt.Image getDisplay() {
    return display.getImage();
  }


  public String setSingleInput(String title) {
    CustomDialog sizeSelector = new CustomDialog(title,
            this);
    sizeSelector.setVisible(true);
    return sizeSelector.getValidatedText();
  }

  public ArrayList<String> setFlag() {
    FlagDialog flagSelector = new FlagDialog(this);
    flagSelector.setVisible(true);
    return flagSelector.getArgumentsHolder();
  }

  public ArrayList<String> setRainbow() {
    RainbowDialog rainbowSelector = new RainbowDialog(this);
    rainbowSelector.setVisible(true);
    return rainbowSelector.getArgumentsHolder();
//=======
//  private void showImage(int[][][] srcPixArray) {
//    BufferedImage pic = ImageUtil.convertToImage(srcPixArray,w,h);
//    ImageIcon ic = new ImageIcon(pic);
//    imageLabel.setIcon(ic);
//    imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
//    imageLabel.repaint();
//>>>>>>> 0dacf5059d98dc07a7791c2ab1a7269171c5f1ed
//  }
  }

  public void cantDo(String command) {
    JOptionPane.showMessageDialog(this, "Has no more " + command + " history operation.",
                 "notification", JOptionPane.INFORMATION_MESSAGE);
  }
}

