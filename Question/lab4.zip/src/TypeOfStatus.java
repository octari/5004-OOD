/**
 * This enumerated type represents the status of the question, required or optional.
 */
public enum TypeOfStatus {
  Required, Optional
}
